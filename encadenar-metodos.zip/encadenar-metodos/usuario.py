class User:
    def __init__(self, name, email_address):
        self.name = name
        self.email = email_address
        self.account_balance = 0

    def make_deposit(self, amount):
        if amount > 0:
            self.account_balance += amount
        else:
            print("El monto del depósito debe ser mayor a cero.")
        return self

    def bank_draft(self, amount):
        if amount > 0:
            if self.account_balance >= amount:
                self.account_balance -= amount
        else:
            print("El monto del retiro debe ser mayor a cero.")
        return self

    def get_balance(self):
        return self.account_balance


alejandra = User("Alejandra R.", "alejandra@python.com")
natalia = User("Natalia R.", "natalia@python.com")
claudia = User("Claudia R.", "claudia@python.com")

alejandra.make_deposit(300).make_deposit(100).make_deposit(50).bank_draft(300)
natalia.make_deposit(500).make_deposit(200).bank_draft(200).bank_draft(200)
claudia.make_deposit(800).bank_draft(200).bank_draft(500).bank_draft(300)

users = [alejandra, natalia, claudia]

for user in users:
    print(f"Recibirá un comprobante en el correo {user.email}")
    print(f"El saldo de la cuenta del usuario {user.name} es: {user.get_balance()}")
    print()